---
name: Nightly build of release binaries failed
about: Used to submit issues related to binaries release workflow
title: 'Attention: Nightly build of release binaries failed'
labels: ['build-package', 'priority']
assignees: ''

---

**Nightly build of release binaries failed**

Hi there:

If you see me here that means there is a release failure for the nightly build

Please **click the status badge** to see more details: [![Nightly Build](https://github.com/nushell/nushell/actions/workflows/nightly-build.yml/badge.svg)](https://github.com/nushell/nushell/actions/workflows/nightly-build.yml)
